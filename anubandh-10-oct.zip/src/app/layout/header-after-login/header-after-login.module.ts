import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes , RouterModule } from '@angular/router';
import { HeaderAfterLoginComponent } from './header-after-login.component';
 
// const HeaderAfterLogin: Routes = [{path: '', component: HeaderAfterLoginComponent}]

@NgModule({
  declarations: [
 
  ],
  imports: [
    CommonModule,
  RouterModule,
  ]
})
export class HeaderAfterLoginModule { }
