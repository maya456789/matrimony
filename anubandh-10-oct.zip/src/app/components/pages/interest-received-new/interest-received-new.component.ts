import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-interest-received-new',
  templateUrl: './interest-received-new.component.html',
  styleUrls: ['./interest-received-new.component.css']
})
export class InterestReceivedNewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  cards = [
    {
      img: 'assets/img/Group 2123.png',
      id: '215AD95',
      view: '1214',
      name: 'Sayali Bompiwar',
      address: '29, Pune, India',
      education: 'MBA, Project Manager',
      time:'1 hour ago',
    },
    {
      img: 'assets/img/Group 2123.png',
      id: '215AD95',
      view: '1214',
      name: 'Sayali Bompiwar',
      address: '29, Pune, India',
      education: 'MBA, Project Manager',
      time:'1 hour ago',
    },
    {
      img: 'assets/img/Group 2123.png',
      id: '215AD95',
      view: '1214',
      name: 'Sayali Bompiwar',
      address: '29, Pune, India',
      education: 'MBA, Project Manager',
      time:'1 hour ago',
    },
    {
      img: 'assets/img/Group 2123.png',
      id: '215AD95',
      view: '1214',
      name: 'Sayali Bompiwar',
      address: '29, Pune, India',
      education: 'MBA, Project Manager',
      time:'1 hour ago',
    },
    {
      img: 'assets/img/Group 2123.png',
      id: '215AD95',
      view: '1214',
      name: 'Sayali Bompiwar',
      address: '29, Pune, India',
      education: 'MBA, Project Manager',
      time:'1 hour ago',
    },
    {
      img: 'assets/img/Group 2123.png',
      id: '215AD95',
      view: '1214',
      name: 'Sayali Bompiwar',
      address: '29, Pune, India',
      education: 'MBA, Project Manager',
      time:'1 hour ago',
    },
    {
      img: 'assets/img/Group 2123.png',
      id: '215AD95',
      view: '1214',
      name: 'Sayali Bompiwar',
      address: '29, Pune, India',
      education: 'MBA, Project Manager',
      time:'1 hour ago',
    },
    {
      img: 'assets/img/Group 2123.png',
      id: '215AD95',
      view: '1214',
      name: 'Sayali Bompiwar',
      address: '29, Pune, India',
      education: 'MBA, Project Manager',
      time:'1 hour ago',
    },
    {
      img: 'assets/img/Group 2123.png',
      id: '215AD95',
      view: '1214',
      name: 'Sayali Bompiwar',
      address: '29, Pune, India',
      education: 'MBA, Project Manager',
      time:'1 hour ago',
    },
    {
      img: 'assets/img/Group 2123.png',
      id: '215AD95',
      view: '1214',
      name: 'Sayali Bompiwar',
      address: '29, Pune, India',
      education: 'MBA, Project Manager',
      time:'1 hour ago',
    },
    {
      img: 'assets/img/Group 2123.png',
      id: '215AD95',
      view: '1214',
      name: 'Sayali Bompiwar',
      address: '29, Pune, India',
      education: 'MBA, Project Manager',
      time:'1 hour ago',
    },
    {
      img: 'assets/img/Group 2123.png',
      id: '215AD95',
      view: '1214',
      name: 'Sayali Bompiwar',
      address: '29, Pune, India',
      education: 'MBA, Project Manager',
      time:'1 hour ago',
    },
    {
      img: 'assets/img/Group 2123.png',
      id: '215AD95',
      view: '1214',
      name: 'Sayali Bompiwar',
      address: '29, Pune, India',
      education: 'MBA, Project Manager',
      time:'1 hour ago',
    },
    {
      img: 'assets/img/Group 2123.png',
      id: '215AD95',
      view: '1214',
      name: 'Sayali Bompiwar',
      address: '29, Pune, India',
      education: 'MBA, Project Manager',
      time:'1 hour ago',
    },
    {
      img: 'assets/img/Group 2123.png',
      id: '215AD95',
      view: '1214',
      name: 'Sayali Bompiwar',
      address: '29, Pune, India',
      education: 'MBA, Project Manager',
      time:'1 hour ago',
    },
    {
      img: 'assets/img/Group 2123.png',
      id: '215AD95',
      view: '1214',
      name: 'Sayali Bompiwar',
      address: '29, Pune, India',
      education: 'MBA, Project Manager',
      time:'1 hour ago',
    },
    {
      img: 'assets/img/Group 2123.png',
      id: '215AD95',
      view: '1214',
      name: 'Sayali Bompiwar',
      address: '29, Pune, India',
      education: 'MBA, Project Manager',
      time:'1 hour ago',
    },
    {
      img: 'assets/img/Group 2123.png',
      id: '215AD95',
      view: '1214',
      name: 'Sayali Bompiwar',
      address: '29, Pune, India',
      education: 'MBA, Project Manager',
      time:'1 hour ago',
    },
   
  

  ]

}
