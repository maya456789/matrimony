import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-interest-sent',
  templateUrl: './interest-sent.component.html',
  styleUrls: ['./interest-sent.component.css']
})
export class InterestSentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  
  cards = [
    {
      img: 'assets/img/Group 2123.png',
      id: '215AD95',
      view: '1214',
      name: 'Sayali Bompiwar',
      address: '29, Pune, India',
      education: 'MBA, Project Manager'
    },
    {
      img: 'assets/img/02.png',
      id: '215AD95',
      view: '1214',
      name: 'Sayali Bompiwar',
      address: '29, Pune, India',
      education: 'MBA, Project Manager'
    },
    {
      img: 'assets/img/02.png',
      id: '215AD95',
      view: '1214',
      name: 'Sayali Bompiwar',
      address: '29, Pune, India',
      education: 'MBA, Project Manager'
    },
    {
      img: 'assets/img/02.png',
      id: '215AD95',
      view: '1214',
      name: 'Sayali Bompiwar',
      address: '29, Pune, India',
      education: 'MBA, Project Manager'
    },
    {
      img: 'assets/img/02.png',
      id: '215AD95',
      view: '1214',
      name: 'Sayali Bompiwar',
      address: '29, Pune, India',
      education: 'MBA, Project Manager'
    },
    {
      img: 'assets/img/02.png',
      id: '215AD95',
      view: '1214',
      name: 'Sayali Bompiwar',
      address: '29, Pune, India',
      education: 'MBA, Project Manager'
    },
   
  
  

  ];

}
