import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-interest-accepted',
  templateUrl: './interest-accepted.component.html',
  styleUrls: ['./interest-accepted.component.css']
})
export class InterestAcceptedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  cards = [
    {
      img: 'assets/img/Group 2123.png',
      id: '215AD95',
      name: 'Sayali Bompiwar',
      address: '29, Pune, India',
      education: 'MBA, Project Manager',
      date: '19/02/2023',

    },
    {
      img: 'assets/img/Group 2123.png',
      id: '215AD95',
      name: 'Sayali Bompiwar',
      address: '29, Pune, India',
      education: 'MBA, Project Manager',
      date: '19/02/2023',

    },
    {
      img: 'assets/img/Group 2123.png',
      id: '215AD95',
      name: 'Sayali Bompiwar',
      address: '29, Pune, India',
      education: 'MBA, Project Manager',
      date: '19/02/2023',

    },
    {
      img: 'assets/img/Group 2123.png',
      id: '215AD95',
      name: 'Sayali Bompiwar',
      address: '29, Pune, India',
      education: 'MBA, Project Manager',
      date: '19/02/2023',

    },
    {
      img: 'assets/img/Group 2123.png',
      id: '215AD95',
      name: 'Sayali Bompiwar',
      address: '29, Pune, India',
      education: 'MBA, Project Manager',
      date: '19/02/2023',

    },
    {
      img: 'assets/img/Group 2123.png',
      id: '215AD95',
      name: 'Sayali Bompiwar',
      address: '29, Pune, India',
      education: 'MBA, Project Manager',
      date: '19/02/2023',

    },
    {
      img: 'assets/img/Group 2123.png',
      id: '215AD95',
      name: 'Sayali Bompiwar',
      address: '29, Pune, India',
      education: 'MBA, Project Manager',
      date: '19/02/2023',

    },
    {
      img: 'assets/img/Group 2123.png',
      id: '215AD95',
      name: 'Sayali Bompiwar',
      address: '29, Pune, India',
      education: 'MBA, Project Manager',
      date: '19/02/2023',

    },

  ]
}
