import { Component } from '@angular/core';

@Component({
  selector: 'app-my-favourite-profiles',
  templateUrl: './my-favourite-profiles.component.html',
  styleUrls: ['./my-favourite-profiles.component.css']
})
export class MyFavouriteProfilesComponent {

  cards = [
    {
      img: 'assets/img/Group 2123.png',
      id: '215AD95',
      name: 'Sayali Bompiwar',
      address: '29, Pune, India',
      education: 'MBA, Project Manager',
      date: '19/02/2023',
      received_interest:true

    },
    {
      img: 'assets/img/Group 2123.png',
      id: '215AD95',
      name: 'Sayali Bompiwar',
      address: '29, Pune, India',
      education: 'MBA, Project Manager',
      date: '19/02/2023',
      received_interest:false
    },
    {
      img: 'assets/img/Group 2123.png',
      id: '215AD95',
      name: 'Sayali Bompiwar',
      address: '29, Pune, India',
      education: 'MBA, Project Manager',
      date: '19/02/2023',
      received_interest:true
    },
    {
      img: 'assets/img/Group 2123.png',
      id: '215AD95',
      name: 'Sayali Bompiwar',
      address: '29, Pune, India',
      education: 'MBA, Project Manager',
      date: '19/02/2023',
      received_interest:true
    },
    {
      img: 'assets/img/Group 2123.png',
      id: '215AD95',
      name: 'Sayali Bompiwar',
      address: '29, Pune, India',
      education: 'MBA, Project Manager',
      date: '19/02/2023',
      received_interest:false
    },
    {
      img: 'assets/img/Group 2123.png',
      id: '215AD95',
      name: 'Sayali Bompiwar',
      address: '29, Pune, India',
      education: 'MBA, Project Manager',
      date: '19/02/2023',
      received_interest:true
    },
    {
      img: 'assets/img/Group 2123.png',
      id: '215AD95',
      name: 'Sayali Bompiwar',
      address: '29, Pune, India',
      education: 'MBA, Project Manager',
      date: '19/02/2023',
      received_interest:true
    },
    {
      img: 'assets/img/Group 2123.png',
      id: '215AD95',
      name: 'Sayali Bompiwar',
      address: '29, Pune, India',
      education: 'MBA, Project Manager',
      date: '19/02/2023',
      received_interest:false
    },

  ]

}
