import { Component } from '@angular/core';

@Component({
  selector: 'app-registration-thankyou',
  templateUrl: './registration-thankyou.component.html',
  styleUrls: ['./registration-thankyou.component.css']
})
export class RegistrationThankyouComponent {

}
