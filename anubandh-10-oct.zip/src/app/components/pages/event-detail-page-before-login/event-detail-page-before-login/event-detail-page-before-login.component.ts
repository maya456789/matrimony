import { Component } from '@angular/core';

@Component({
  selector: 'app-event-detail-page-before-login',
  templateUrl: './event-detail-page-before-login.component.html',
  styleUrls: ['./event-detail-page-before-login.component.css']
})
export class EventDetailPageBeforeLoginComponent {

  cards = [
    {
      title: 'Aim is to Reach My Goal With Best Plan',
      description: 'Some quick example text to build on the card title and make up the bulk of the card content',
      buttonText: 'Button',
      img: 'assets/img/02.png',
      auther:'anubhandh',
      date:'25th October 2022'
    },
    {
      title: 'Aim is to Reach My Goal With Best Plan',
      description: 'Some quick example text to build on the card title and make up the bulk of the card content',
      buttonText: 'Button',
      img: 'assets/img/02.png',
      auther:'anubhandh',
      date:'25th October 2022'
    },
    {
      title: 'Aim is to Reach My Goal With Best Plan',
      description: 'Some quick example text to build on the card title and make up the bulk of the card content',
      buttonText: 'Button',
      img: 'assets/img/02.png',
      auther:'anubhandh',
      date:'25th October 2022'
    },
    {
      title: 'Aim is to Reach My Goal With Best Plan',
      description: 'Some quick example text to build on the card title and make up the bulk of the card content',
      buttonText: 'Button',
      img: 'assets/img/02.png',
      auther:'anubhandh',
      date:'25th October 2022'
    },
 

  ];

}
