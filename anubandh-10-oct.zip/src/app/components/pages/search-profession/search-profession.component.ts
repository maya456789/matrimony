import { Component } from '@angular/core';

@Component({
  selector: 'app-search-profession',
  templateUrl: './search-profession.component.html',
  styleUrls: ['./search-profession.component.css']
})
export class SearchProfessionComponent {



  cards = [
    {
      id:'215AD35',
      name:'Sayali Bompilwar',
      age: '29 ',
      img: 'assets/img/Group 2123.png',
      address:'pune,India',
      occupation:'MBA, Project Manager',   
      lastseen:'last seen on 16-10-2022'
    },
    
      {
        id:'215AD35',
        name:'Sayali Bompilwar',
        age: '29 ',
        img: 'assets/img/Group 2123.png',
        address:'pune,India',
        occupation:'MBA, Project Manager',   
        lastseen:'last seen on 16-10-2022'
      },
      {
        id:'215AD35',
        name:'Sayali Bompilwar',
        age: '29 ',
        img: 'assets/img/Group 2123.png',
        address:'pune,India',
        occupation:'MBA, Project Manager',   
        lastseen:'last seen on 16-10-2022'
      },
      {
        id:'215AD35',
        name:'Sayali Bompilwar',
        age: '29 ',
        img: 'assets/img/Group 2123.png',
        address:'pune,India',
        occupation:'MBA, Project Manager',   
        lastseen:'last seen on 16-10-2022'
      },{
        id:'215AD35',
        name:'Sayali Bompilwar',
        age: '29 ',
        img: 'assets/img/Group 2123.png',
        address:'pune,India',
        occupation:'MBA, Project Manager',  
         lastseen:'last seen on 16-10-2022'
      },{
        id:'215AD35',
        name:'Sayali Bompilwar',
        age: '29 ',
        img: 'assets/img/Group 2123.png',
        address:'pune,India',
        occupation:'MBA, Project Manager',   
        lastseen:'last seen on 16-10-2022'
      },{
        id:'215AD35',
        name:'Sayali Bompilwar',
        age: '29 ',
        img: 'assets/img/Group 2123.png',
        address:'pune,India',
        occupation:'MBA, Project Manager',   
        lastseen:'last seen on 16-10-2022'
      },{
        id:'215AD35',
        name:'Sayali Bompilwar',
        age: '29 ',
        img: 'assets/img/Group 2123.png',
        address:'pune,India',
        occupation:'MBA, Project Manager',   
        lastseen:'last seen on 16-10-2022'
      },{
        id:'215AD35',
        name:'Sayali Bompilwar',
        age: '29 ',
        img: 'assets/img/Group 2123.png',
        address:'pune,India',
        occupation:'MBA, Project Manager',   
        lastseen:'last seen on 16-10-2022'
      },{
        id:'215AD35',
        name:'Sayali Bompilwar',
        age: '29 ',
        img: 'assets/img/Group 2123.png',
        address:'pune,India',
        occupation:'MBA, Project Manager',   
        lastseen:'last seen on 16-10-2022'
      },{
        id:'215AD35',
        name:'Sayali Bompilwar',
        age: '29 ',
        img: 'assets/img/Group 2123.png',
        address:'pune,India',
        occupation:'MBA, Project Manager',   
        lastseen:'last seen on 16-10-2022'
      },{
        id:'215AD35',
        name:'Sayali Bompilwar',
        age: '29 ',
        img: 'assets/img/Group 2123.png',
        address:'pune,India',
        occupation:'MBA, Project Manager',   
        lastseen:'last seen on 16-10-2022'
      },{
        id:'215AD35',
        name:'Sayali Bompilwar',
        age: '29 ',
        img: 'assets/img/Group 2123.png',
        address:'pune,India',
        occupation:'MBA, Project Manager',   lastseen:'last seen on 16-10-2022'
      },{
        id:'215AD35',
        name:'Sayali Bompilwar',
        age: '29 ',
        img: 'assets/img/Group 2123.png',
        address:'pune,India',
        occupation:'MBA, Project Manager',   lastseen:'last seen on 16-10-2022'
      },{
        id:'215AD35',
        name:'Sayali Bompilwar',
        age: '29 ',
        img: 'assets/img/Group 2123.png',
        address:'pune,India',
        occupation:'MBA, Project Manager',   lastseen:'last seen on 16-10-2022', 
      },
      
    
  ];




}
