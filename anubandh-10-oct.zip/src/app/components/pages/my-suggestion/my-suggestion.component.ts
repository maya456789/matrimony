import { Component } from '@angular/core';

@Component({
  selector: 'app-my-suggestion',
  templateUrl: './my-suggestion.component.html',
  styleUrls: ['./my-suggestion.component.css']
})
export class MySuggestionComponent {

  cards = [
    {
      id:'215AD35',
      name:'Sayali Bompilwar',
      age: '29 ',
      img: 'assets/img/Group 2123.png',
      address:'pune,India',
      occupation:'MBA, Project Manager',   
      lastseen:'last seen on 16-10-2022'
    },
    
      {
        id:'215AD35',
        name:'Sayali Bompilwar',
        age: '29 ',
        img: 'assets/img/Group 2123.png',
        address:'pune,India',
        occupation:'MBA, Project Manager',   
        lastseen:'last seen on 16-10-2022'
      },
      {
        id:'215AD35',
        name:'Sayali Bompilwar',
        age: '29 ',
        img: 'assets/img/Group 2123.png',
        address:'pune,India',
        occupation:'MBA, Project Manager',   
        lastseen:'last seen on 16-10-2022'
      },
      {
        id:'215AD35',
        name:'Sayali Bompilwar',
        age: '29 ',
        img: 'assets/img/Group 2123.png',
        address:'pune,India',
        occupation:'MBA, Project Manager',   
        lastseen:'last seen on 16-10-2022'
      },{
        id:'215AD35',
        name:'Sayali Bompilwar',
        age: '29 ',
        img: 'assets/img/Group 2123.png',
        address:'pune,India',
        occupation:'MBA, Project Manager',  
         lastseen:'last seen on 16-10-2022'
      },{
        id:'215AD35',
        name:'Sayali Bompilwar',
        age: '29 ',
        img: 'assets/img/Group 2123.png',
        address:'pune,India',
        occupation:'MBA, Project Manager',   
        lastseen:'last seen on 16-10-2022'
      },{
        id:'215AD35',
        name:'Sayali Bompilwar',
        age: '29 ',
        img: 'assets/img/Group 2123.png',
        address:'pune,India',
        occupation:'MBA, Project Manager',   
        lastseen:'last seen on 16-10-2022'
      },{
        id:'215AD35',
        name:'Sayali Bompilwar',
        age: '29 ',
        img: 'assets/img/Group 2123.png',
        address:'pune,India',
        occupation:'MBA, Project Manager',   
        lastseen:'last seen on 16-10-2022'
      },{
        id:'215AD35',
        name:'Sayali Bompilwar',
        age: '29 ',
        img: 'assets/img/Group 2123.png',
        address:'pune,India',
        occupation:'MBA, Project Manager',   
        lastseen:'last seen on 16-10-2022'
      },{
        id:'215AD35',
        name:'Sayali Bompilwar',
        age: '29 ',
        img: 'assets/img/Group 2123.png',
        address:'pune,India',
        occupation:'MBA, Project Manager',   
        lastseen:'last seen on 16-10-2022'
      },{
        id:'215AD35',
        name:'Sayali Bompilwar',
        age: '29 ',
        img: 'assets/img/Group 2123.png',
        address:'pune,India',
        occupation:'MBA, Project Manager',   
        lastseen:'last seen on 16-10-2022'
      },{
        id:'215AD35',
        name:'Sayali Bompilwar',
        age: '29 ',
        img: 'assets/img/Group 2123.png',
        address:'pune,India',
        occupation:'MBA, Project Manager',   
        lastseen:'last seen on 16-10-2022'
      }
    
  ];
}
